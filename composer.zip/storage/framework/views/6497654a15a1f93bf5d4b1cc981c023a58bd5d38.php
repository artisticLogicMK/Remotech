<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <meta name="description" content="Remotech is a job listing and search platform that aims to give a fast and modern user experience for job employers and job seekers." />
	    <meta property="og:image" content="http://remotech.us-east-1.elasticbeanstalk.com/social.png" />
        <meta name="theme-color" content="#38bdf8">
        <link rel="icon" href="<?php echo e(asset('ico.png')); ?>">

        <title inertia><?php echo e(config('app.name', 'Remotech')); ?></title>

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

        <!-- Scripts -->
        <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->head; } ?>
    </head>
    <body class="antialiased select-none">
        <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

        <?php if(app()->environment('local')): ?>
            <script src="http://localhost:8080/js/bundle.js"></script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\Users\Pharoah\Desktop\pros\rmt\resources\views/app.blade.php ENDPATH**/ ?>