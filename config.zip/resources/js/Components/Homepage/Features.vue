<script setup>
import AOS from 'aos'
import { onMounted } from 'vue'

onMounted(() => {
  AOS.init()
})
</script>

<template>
  <div class="w-full bg-gradient-to-br from-sky-400 to-teal-400 px-3 py-10 relative overflow-hidden">
    <div class="absolute top-0 left-0 w-full h-full bg-transparent text-center">
      <img src="/images/diamonds.svg" class="w-[98%] rotate-[180deg] opacity-[.08] inline-block">
      <img src="/images/diamonds.svg" class="w-[98%] rotate-[180deg] opacity-[.08] inline-block">
    </div>
    
    <div class="max-w-2xl mx-auto relative">
      
      <div class="mb-2" data-aos="slide-up">
        <h1 class="text-white/90 font-semibold text-2xl">The Benefits of using Remotech</h1>
        <p class="text-base text-white">Posting jobs on Remotech is easier and friendlier than any other job board and you have candidates from all around the world to see your postings.</p>
      </div>
      
      <div class="sm:flex items-center justify-center">
        
        <img src="/images/feature.svg" class="hidden sm:block w-36 mr-3" data-aos="zoom-in" data-aos-delay="250">
        
        <div class="mt-3 sm:mt-0">
          <div class="flex text-white mb-4" data-aos="fade-up" data-aos-delay="250">
            <div class="border border-white/95 rounded px-1.5 py-0 inline-block h-fit mr-2 sm:mr-3 text-lg">
              <i class="la la-globe"></i>
            </div>
            <div>
              <h1 class="font-semibold text-sm sm:text-base leading-none">Wide reach.</h1>
              <p class="text-sm sm:text-base">Posting your job on Remotech involves you reaching over many countries online. This means you have the benefit of gaining exposure to a huge range of tech enthusiasts seeking job locally or internationally.
              </p>
            </div>
          </div>
          <div class="flex text-white/95 mb-4" data-aos="fade-up" data-aos-delay="450">
            <div class="border border-white/95 rounded px-1.5 py-0 inline-block h-fit mr-2 sm:mr-3 text-lg">
              <i class="la la-crosshairs"></i>
            </div>
            <div>
              <h1 class="font-semibold text-sm sm:text-base leading-none">We target everybody.</h1>
              <p class="text-sm sm:text-base">We have many job postings from tech companies which target seasonal workers, temporary and contract job seekers, high school graduates, and recent college graduates.</p>
            </div>
          </div>
          <div class="flex text-white/95" data-aos="fade-up" data-aos-delay="650">
            <div class="border border-white/95 rounded px-1.5 py-0 inline-block h-fit mr-2 sm:mr-3 text-lg">
              <i class="la la-map-signs"></i>
            </div>
            <div>
              <h1 class="font-semibold text-sm sm:text-base leading-none">Easy navigation and usage.</h1>
              <p class="text-sm sm:text-base">We have thoughtfully designed our platform to be friendly and easily accessible, and hassle free for job posters and job seekers.</p>
            </div>
          </div>
          
        </div>
        
      </div>
    
    </div>
    
  </div>
</template>