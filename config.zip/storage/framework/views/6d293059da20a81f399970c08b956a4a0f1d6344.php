<?php echo e($slot); ?>

<?php /**PATH C:\Users\Pharoah\Desktop\pros\rmt\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>