<?php echo e($slot); ?>

<?php /**PATH /data/data/com.termux/files/home/remotech/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>