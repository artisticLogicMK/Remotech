<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /data/data/com.termux/files/home/remotech/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>