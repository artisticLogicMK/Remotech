[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Pharoah\Desktop\pros\rmt\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>